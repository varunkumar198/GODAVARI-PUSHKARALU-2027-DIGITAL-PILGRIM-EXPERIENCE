const filter = document.getElementById('filter');
const noResults = document.getElementById('noResults');
filter?.addEventListener('input', () => {
  const q = filter.value.trim().toLowerCase();
  let shown = 0;
  document.querySelectorAll('#infoGrid .tile').forEach(c => {
    const match = c.dataset.search.includes(q);
    c.hidden = !match;
    if (match) shown++;
  });
  if (noResults) noResults.hidden = shown > 0;
});

// Larger-text toggle: scales the root font size, remembers the choice, updates label + aria-pressed.
const sizeBtn = document.getElementById('textSize');
function setLarge(on) {
  document.documentElement.classList.toggle('large', on);
  if (sizeBtn) {
    sizeBtn.textContent = on ? LABELS.normal : LABELS.large;
    sizeBtn.setAttribute('aria-pressed', String(on));
  }
}
let savedLarge = false;
try { savedLarge = localStorage.getItem('largeText') === '1'; } catch (e) {}
setLarge(savedLarge);
sizeBtn?.addEventListener('click', () => {
  const on = !document.documentElement.classList.contains('large');
  setLarge(on);
  try { localStorage.setItem('largeText', on ? '1' : '0'); } catch (e) {}
});

async function askGuide() {
  const q = document.getElementById('question').value.trim();
  const out = document.getElementById('answer');
  if (!q) { out.textContent = 'Please enter a question.'; return; }
  out.textContent = 'Checking the guide\u2026';
  try {
    const r = await fetch('/api/guide', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: q, lang: LANG })
    });
    const d = await r.json();
    if (!r.ok || !d.answer) throw new Error(d.error || 'Bad response');
    out.textContent = d.answer;
  } catch (e) {
    out.textContent = 'The guide is unavailable. Please consult official event information or an authorised help desk.';
  }
}
document.getElementById('ask')?.addEventListener('click', askGuide);
document.getElementById('question')?.addEventListener('keydown', e => { if (e.key === 'Enter') askGuide(); });
