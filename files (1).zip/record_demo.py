import subprocess, time, os, sys, shutil, glob, urllib.request
from playwright.sync_api import sync_playwright

# Put this file in the project folder (next to app.py) and run:  python record_demo.py
# Needs (one time):  pip install playwright imageio-ffmpeg   and   playwright install chromium
PROJ = os.path.dirname(os.path.abspath(__file__))
PORT = "5055"
BASE = f"http://127.0.0.1:{PORT}"
OUT_DIR = os.path.join(PROJ, "demo_raw")
FINAL = os.path.join(PROJ, "Godavari_Pushkaralu_PS12_Demo_clean_Telugu.mp4")
shutil.rmtree(OUT_DIR, ignore_errors=True); os.makedirs(OUT_DIR)

srv = subprocess.Popen([sys.executable, "app.py"], cwd=PROJ, env={**os.environ, "PORT": PORT},
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(50):
    try: urllib.request.urlopen(BASE + "/health", timeout=1); break
    except Exception: time.sleep(0.2)

INIT = r"""
(() => {
  window.__cap = (t) => {
    try { sessionStorage.setItem('cap', t || ''); } catch(e) {}
    const c = document.getElementById('__cap');
    if (c) { c.textContent = t || ''; c.style.opacity = t ? 1 : 0; }
  };
  const mk = () => {
    if (document.getElementById('__cap')) return;
    const c = document.createElement('div'); c.id = '__cap';
    c.style.cssText = 'position:fixed;left:0;right:0;bottom:0;padding:18px 56px;background:rgba(20,28,36,.9);color:#fff;font:600 26px/1.35 system-ui,Segoe UI,Arial,sans-serif;text-align:center;z-index:2147483646;pointer-events:none;transition:opacity .3s';
    let t = ''; try { t = sessionStorage.getItem('cap') || ''; } catch(e) {}
    c.textContent = t; c.style.opacity = t ? 1 : 0;
    document.documentElement.appendChild(c);
    const d = document.createElement('div'); d.id = '__cur';
    let x = -50, y = -50;
    try { x = +sessionStorage.getItem('cx') || -50; y = +sessionStorage.getItem('cy') || -50; } catch(e) {}
    d.style.cssText = `position:fixed;left:${x}px;top:${y}px;width:24px;height:24px;border-radius:50%;background:rgba(215,166,90,.6);border:3px solid #a95f3b;z-index:2147483647;pointer-events:none;transform:translate(-50%,-50%) scale(1);transition:transform .15s`;
    document.documentElement.appendChild(d);
    document.addEventListener('mousemove', e => {
      d.style.left = e.clientX + 'px'; d.style.top = e.clientY + 'px';
      try { sessionStorage.setItem('cx', e.clientX); sessionStorage.setItem('cy', e.clientY); } catch(err) {}
    }, true);
    document.addEventListener('mousedown', () => d.style.transform = 'translate(-50%,-50%) scale(0.6)', true);
    document.addEventListener('mouseup', () => d.style.transform = 'translate(-50%,-50%) scale(1)', true);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mk); else mk();
})();
"""

CARD = """
(([title, sub, foot]) => {
  const o = document.createElement('div'); o.id = '__card';
  o.style.cssText = 'position:fixed;inset:0;background:linear-gradient(110deg,#f0dfc7,#fbf3e8);z-index:2147483647;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;font-family:system-ui,Segoe UI,Arial,sans-serif;color:#1e2b35;padding:40px';
  o.innerHTML = `<div style="font-size:14px;letter-spacing:3px;font-weight:800;color:#a95f3b">${foot}</div>
  <div style="font-size:64px;font-weight:900;letter-spacing:-1.5px;margin:18px 0 10px">${title}</div>
  <div style="font-size:26px;color:#53616b;max-width:900px;line-height:1.4">${sub}</div>`;
  document.documentElement.appendChild(o);
})
"""

def run():
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1280, "height": 720},
                            record_video_dir=OUT_DIR, record_video_size={"width": 1280, "height": 720})
        ctx.add_init_script(INIT)
        page = ctx.new_page()
        vid = page.video

        def cap(t): page.evaluate("t => window.__cap(t)", t)
        def wait(s): page.wait_for_timeout(int(s * 1000))
        def scroll_to(sel, block='start'):
            page.evaluate("([s,b]) => document.querySelector(s).scrollIntoView({behavior:'smooth', block:b})", [sel, block])
            wait(1.4)
        def move_to(sel):
            bb = page.locator(sel).first.bounding_box()
            page.mouse.move(bb["x"] + bb["width"] / 2, bb["y"] + min(bb["height"] / 2, 30), steps=30)
        def click(sel):
            move_to(sel); wait(0.3); page.locator(sel).first.click(); wait(0.2)

        page.goto(BASE + "/"); page.wait_for_load_state("load"); wait(0.5)

        # Title card
        page.evaluate(CARD, ["Godavari Pushkaralu 2027", "Digital Pilgrim Experience &middot; accessible event information, heritage learning and virtual participation",
                             "PROBLEM STATEMENT 12 &middot; CONCEPT PROTOTYPE"])
        wait(4.0)
        page.evaluate("document.getElementById('__card').remove()")

        cap("Millions of pilgrims need clear event information, in their own language.")
        page.mouse.move(640, 360, steps=10); wait(4.5)

        cap("One click switches between English, Telugu, Hindi and Tamil.")
        move_to("select"); wait(0.5)
        for code, hold in [("te", 3.5), ("hi", 2.4), ("ta", 2.4), ("en", 1.2)]:
            page.select_option("select", code); page.wait_for_load_state("load"); wait(hold)

        cap("Visitor information is searchable: event guidance, routes, facilities and accessibility.")
        scroll_to("#info")
        click("#filter"); page.keyboard.type("accessible", delay=140); wait(3.0)
        page.fill("#filter", ""); page.dispatch_event("#filter", "input"); wait(0.8)

        cap("Heritage cards introduce regional culture and history, reviewed by local experts.")
        scroll_to("#heritage"); page.mouse.move(400, 330, steps=25); wait(5.0)

        cap("Virtual participation: a space for official livestreams and digital exhibits.")
        scroll_to("#virtual", "center"); page.mouse.move(900, 300, steps=25); wait(5.0)

        cap("A digital guide answers common questions. This demo is an FAQ, not a live AI model.")
        scroll_to("#guide")
        click("#question"); page.keyboard.type("Where is the bathing ghat?", delay=90); wait(0.4)
        page.keyboard.press("Enter"); wait(3.8)
        page.fill("#question", ""); click("#question"); page.keyboard.type("wheelchair access", delay=90); wait(0.4)
        page.keyboard.press("Enter"); wait(3.8)

        cap("Accessibility options such as larger text help older and low-vision visitors.")
        scroll_to(".accessibility")
        click("#textSize"); wait(3.5)
        scroll_to(".accessibility"); click("#textSize"); wait(1.5)

        cap("Sample content only: replace with verified, organiser-approved information before launch.")
        page.evaluate("window.scrollTo({top:0, behavior:'smooth'})"); wait(1.6)
        page.mouse.move(640, 300, steps=15); wait(3.5)

        cap("")
        page.evaluate(CARD, ["Godavari Pushkaralu 2027", "Concept prototype &middot; sample content only &middot; to be verified by event organisers",
                             "DIGITAL PILGRIM EXPERIENCE"])
        wait(3.5)
        path = vid.path()
        ctx.close(); b.close()
        return path

try:
    path = run()
finally:
    srv.terminate()
print("Recorded:", path)
try:
    import imageio_ffmpeg
    exe = imageio_ffmpeg.get_ffmpeg_exe()
    subprocess.run([exe, "-y", "-i", path, "-c:v", "libx264", "-preset", "slow", "-crf", "20",
                    "-pix_fmt", "yuv420p", "-r", "30", "-movflags", "+faststart", FINAL], check=True)
    print("Done! Video saved to:", FINAL)
except Exception as e:
    print("Could not convert to MP4 (", e, "). The WebM file above is still a valid video.")
